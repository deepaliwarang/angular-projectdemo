export const environment = {
  production: true,
  // socketUrl: 'http://138.197.68.176:3000' 
};
